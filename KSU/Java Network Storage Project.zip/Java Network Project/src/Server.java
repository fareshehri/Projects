import java.net.*;
import java.util.*;
import java.io.*;
public class Server {
	private Socket socket = null;
	private ServerSocket server =null;
	private static DataInputStream input =null;
	private static DataOutputStream output =null;
	Csv cs=new Csv();
	int count =0;

	public Server(int port) {
		try {
			server = new ServerSocket(port);
			System.out.println("Server: Waiting for client.");
			socket =server.accept();
			input = new DataInputStream(socket.getInputStream());
			output = new DataOutputStream(socket.getOutputStream());
			int done =-1;
			done = input.read();
			
			while (done!=0) {
				if(done==1) {
					String name = input.readUTF();
					String tot = (name);
					System.out.println("Server: "+tot+" Received.");
					if(cs.check(tot)!=true) {
					cs.save(tot);
					filer("C:\\Java\\Server\\"+tot);
					files("C:\\Java\\Server\\file.csv");
					done = input.read();
					}
				}
				if(done==2) {
					files("C:\\Java\\Server\\file.csv");
					String select =input.readUTF();
					files("C:\\Java\\Server\\"+select);
					done = input.read();
					
			}
				
			}

			if(done==0) {
				input.close();
				output.close();
				socket.close();
				System.out.println("Server: GoodBye.");
}

		} catch (Exception e) {
			System.out.println(e);
		}
	}
	 private static void filer(String fileName) throws Exception{
	        int bytes = 0;
	        FileOutputStream fileOutputStream = new FileOutputStream(fileName);
	        long size = input.readLong();
	        byte[] buffer = new byte[4*1024];
	        while (size > 0 && (bytes = input.read(buffer, 0, (int)Math.min(buffer.length, size))) != -1) {
	            fileOutputStream.write(buffer,0,bytes);
	            size -= bytes;
	        }
	        fileOutputStream.close();
	    }
	 private static void files(String path) throws Exception{
			int bytes = 0;
			File file = new File(path);
			FileInputStream fileInputStream = new FileInputStream(file);
			output.writeLong(file.length());  
			byte[] buffer = new byte[4*1024];
			while ((bytes=fileInputStream.read(buffer))!=-1){
				output.write(buffer,0,bytes);
				output.flush();
			}
			fileInputStream.close();
			}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Server s =new Server(5613);
	}
}
