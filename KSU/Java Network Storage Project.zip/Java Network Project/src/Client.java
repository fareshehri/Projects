import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.io.*;
public class Client {
	private Socket socket =null;
	private static DataInputStream input =null;
	private static DataOutputStream output =null;
public Client(String address,int port) {
	try {
		socket=new Socket(address,port);
		System.out.println("Client: Connected to the Server.");
		input = new DataInputStream(socket.getInputStream());
		output = new DataOutputStream(socket.getOutputStream());
		
	}
	catch(Exception e){
		System.out.println(e);
	}
}
	private static void files(String path) throws Exception{
	int bytes = 0;
	File file = new File(path);
	FileInputStream fileInputStream = new FileInputStream(file);
	output.writeLong(file.length());  
	byte[] buffer = new byte[4*1024];
	while ((bytes=fileInputStream.read(buffer))!=-1){
		output.write(buffer,0,bytes);
		output.flush();
	}
	fileInputStream.close();
	}
	
	private static void filer(String fileName) throws Exception{
        int bytes = 0;
        FileOutputStream fileOutputStream = new FileOutputStream(fileName);
        long size = input.readLong();
        byte[] buffer = new byte[4*1024];
        while (size > 0 && (bytes = input.read(buffer, 0, (int)Math.min(buffer.length, size))) != -1) {
            fileOutputStream.write(buffer,0,bytes);
            size -= bytes;
        }
        fileOutputStream.close();
    }
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Client c = new Client("localhost",5613);
		Frame frame = new Frame();
		try {
			new File("C:\\Java\\").mkdirs();
			new File("C:\\Java\\Client\\").mkdirs();
			new File("C:\\Java\\Server\\").mkdirs();
		}
		catch (Exception e){
			
		}
		while(frame.done!=0) {
			System.out.print("");
			if(frame.done==1) {
				c.output.write(1);
				c.output.writeUTF(frame.name);
				c.files(frame.path);
				c.filer("C:\\Java\\Client\\filer.csv");
				frame.done=-1;
			}
			if(frame.done==2) {
				c.output.write(2);
				c.filer("C:\\Java\\Client\\filer.csv");
				while(frame.timer == 1) {
					try {
						TimeUnit.SECONDS.sleep(1);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				System.out.println(frame.name);
				c.output.writeUTF(frame.name);
				filer("C:\\Java\\Client\\"+frame.name);
				frame.done=-1;
			}
				
			if(frame.done==0) {
				try{c.output.write(0);}catch(Exception e) {}
				c.input.close();
				c.output.close();
				c.socket.close();}
		}

		}
		}


	

