import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.LinkedList;


public class Csv {
	LinkedList<String> li = new LinkedList<String>();
	int count;

	public void save(String name) {
	try {
		FileWriter fw = new FileWriter("C:\\Java\\Server\\file.csv",true);
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter pw =new PrintWriter(bw);
		pw.println(name);
		pw.flush();
		pw.close();
	}
	catch(Exception e) {
		// TODO Auto-generated catch block
				e.printStackTrace();
		
	}
}
public void read(String name) {
	try {
		String line = "";
		BufferedReader br = new BufferedReader(new FileReader(name));
		while((line =br.readLine())!=null) {
			//System.out.println(line);
			li.add(line);
			count++;
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		System.out.println();
	}
	
}
public Boolean check(String name) {
	read("C:\\Java\\Server\\file.csv");
	String[] array = new String[li.size()];
	for(int i = 0; i < array.length; i++) {
			array[i] = li.get(i);
	}
	if(array.length<1) {
		return false;
	}
	for(int i=0;i<array.length;i++) {
		if(array[i].equals(name)) {
			return true;
		}}
	return false;
}
public String[] arrayit(LinkedList l) {
	Object[] objectAarray = l.toArray();
    int length = objectAarray.length;;
    String [] stringArray = new String[length];
    for(int i =0; i < length; i++) {
       stringArray[i] = (String) objectAarray[i];
    }
    return stringArray;
}
	public static void main(String[] args) {
		
		
		
	}
}