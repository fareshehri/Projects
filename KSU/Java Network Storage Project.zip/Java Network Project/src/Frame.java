import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;

import javax.swing.*;    
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class Frame extends JFrame implements ActionListener {
	String path=null;
	String ext=null;
	String name=null;
	int done = -1;
	int timer = 1;
	JButton button;
	JButton button1;
	JButton button2;
	ImageIcon icon = new ImageIcon("icon.png");
	
	LinkedList<String> list = new LinkedList<String>();
	Csv cs=new Csv();
	
	Frame(){
	this.setIconImage(icon.getImage());
	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	this.setLayout(new FlowLayout());
	this.pack();
	this.setVisible(true);
	this.setSize(250,250);
	this.getContentPane().setBackground( Color.PINK );
	
	button= new JButton("Upload");
	button.setForeground(Color.WHITE);
	button.setBackground(Color.GRAY);
	button.addActionListener(new ActionListener() {  
        public void actionPerformed(ActionEvent e)
        {
        	JFileChooser fileChooser = new JFileChooser();
        	fileChooser.setCurrentDirectory(new File("."));
        	int res=fileChooser.showOpenDialog(rootPane);//showOpenDialog file to open
        	if(res==JFileChooser.APPROVE_OPTION) {
        		File file =new File(fileChooser.getSelectedFile().getAbsolutePath());
        		String fileName = file.getName();           
        		String fileExtension = fileName.substring(fileName.lastIndexOf(".") + 1, file.getName().length());
        		path = file.toString();
        		done = 1;
        		ext = fileExtension.toString();
        		name = file.getName().toString();
        	}
        	done =1;
        }
	}
	);
	this.add(button);
	
	//download
	button1= new JButton("Download");
	button1.setForeground(Color.WHITE);
	button1.setBackground(Color.GRAY);
	button1.addActionListener(new ActionListener() {  
        public void actionPerformed(ActionEvent e)
        {	
        	done =2;
        	JFrame download = new JFrame();
        	Frame.this.setVisible(false);
    		download.setIconImage(icon.getImage());
        	download.setVisible(true);
        	download.getContentPane().setBackground( Color.PINK );
        	JLabel label = new JLabel("Path");
        	label.setText("You will find the file in (C:\\Java\\Client)");
        	JButton send;
        	JButton exit;
        	try {
				TimeUnit.SECONDS.sleep(1);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	File f = new File("C:\\Java\\Client\\filer.csv");
        	if(f.exists() && !f.isDirectory()) { 
        	
        	cs.read(f.toString());
        	list=cs.li;
    		String[] array = new String[list.size()];
    		for(int i = 0; i < array.length; i++) {
    				array[i] = list.get(i);
    		}
    		JComboBox comboBox = new JComboBox(array);
    		comboBox.setBounds(50, 50,90,20);    
    		
    		send=new JButton("Send");
    		send.setForeground(Color.WHITE);
    		send.setBackground(Color.GRAY);
    		send.addActionListener(new ActionListener() {  
    			public void actionPerformed(ActionEvent e) {
    				name=comboBox.getSelectedItem().toString();
    				timer = 0;
    				list.clear();
    				Frame.this.setVisible(true);
    	        	download.setVisible(false);		
    			}
    		});
    		
    		exit=new JButton("Exit");
    		exit.setForeground(Color.WHITE);
    		exit.setBackground(Color.GRAY);
    		exit.addActionListener(new ActionListener() {  
    			public void actionPerformed(ActionEvent e) {
    				list.clear();
    	    		Frame.this.setVisible(true);
    	        	download.setVisible(false);
    			}
    		});
    		comboBox.getEditor().getEditorComponent().setBackground(Color.CYAN);
    		download.add(comboBox);
    		download.add(send);
    		download.add(exit);
    		download.add(label);
    		download.setLayout(new FlowLayout());    
    		download.setSize(250,250);    
    		download.setVisible(true);

    		}
        	else {
        		JOptionPane.showMessageDialog(null, "No files");
	    		Frame.this.setVisible(true);
	        	download.setVisible(false);
        }       	
        	
        }
        }
	);
	this.add(button1);
	
	//exit
	button2= new JButton("Exit");
	button2.setForeground(Color.WHITE);
	button2.setBackground(Color.GRAY);
	button2.addActionListener(new ActionListener() {  
        public void actionPerformed(ActionEvent e)
        {
    		done =0;
    		dispose();
    		//actionPerformed(null);//makes exception error try to fix it
    		}
        }
	);
	this.add(button2);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}
