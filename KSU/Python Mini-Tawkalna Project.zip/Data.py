import sqlite3


class Data:
    conn = sqlite3.connect("test.db")
    try:
        conn.execute('''CREATE TABLE CLIENT(fname text NOT NULL,
                lname text NOT NULL,
                sex text NOT NULL,
                id VARCHAR(10) PRIMARY KEY NOT NULL,
                birth text NOT NULL,
                vaccine text NOT NULL,
                date text NOT NULL,
                phone VARCHAR(10) NOT NULL);''')
    except:
        pass
        conn.close()

    def __init__(self, fname, lname, sex, id, birth, vaccine, date, phone):
        self.fname = fname
        self.lname = lname
        self.sex = sex
        self.id = id
        self.birth = birth
        self.vaccine = vaccine
        self.date = date
        self.phone = phone

    def addClient(self):
        conn = sqlite3.connect("test.db")
        cursor = conn.execute("SELECT fname, lname, sex, id, birth,vaccine, date, phone from CLIENT")
        for row in cursor:
            if (row[3] == self.id):
                if "and" in row[5]:
                    return False
                else:
                    z = row[5]
                    c = "{} and {}".format(z, self.vaccine)
                    conn.execute("DELETE FROM CLIENT WHERE id='{}'".format(self.id))
                    conn.commit()
                    conn.execute(
                        "INSERT INTO CLIENT VALUES ('{}','{}','{}','{}','{}','{}','{}','{}')".format(self.fname,self.lname,self.sex, self.id,self.birth, c,self.date,self.phone, ))
                    conn.commit()
                    return True

        else:
            conn.execute(
                "INSERT INTO CLIENT VALUES ('{}','{}','{}','{}','{}','{}','{}','{}')".format(self.fname, self.lname,self.sex, self.id,self.birth, self.vaccine,self.date, self.phone))
            conn.commit()
            return True
    conn.close()

    def importClient(imfn,imln,imse,imid,imbi,imva,imda,imph):
        if str(imse).capitalize() in ["Male","Female"]:
            conn = sqlite3.connect("test.db")
            cursor = conn.execute("SELECT fname, lname, sex, id, birth,vaccine, date, phone from CLIENT")
            for row in cursor:
                if (row[3] == imid):
                    if "and" in row[5]:
                        return False
                    else:
                        z = row[5]
                        c = "{} and {}".format(z, imva)
                        conn.execute("DELETE FROM CLIENT WHERE id='{}'".format(imid))
                        conn.commit()
                        conn.execute(
                        "INSERT INTO CLIENT VALUES ('{}','{}','{}','{}','{}','{}','{}','{}')".format(imfn,imln,imse, imid,imbi, c,imda,imph, ))
                        conn.commit()
                        return True

            else:
                conn.execute(
                "INSERT INTO CLIENT VALUES ('{}','{}','{}','{}','{}','{}','{}','{}')".format(imfn, imln,imse, imid,imbi, imva,imda, imph))
                conn.commit()
                return True

    conn.close()

    def checker(self):
        conn = sqlite3.connect("test.db")
        cursor = conn.execute("SELECT fname, lname, sex, id, birth,vaccine, date, phone from CLIENT")
        for row in cursor:
            if row[3] == self:
                if "and" in row[5]:
                    return 2
                if "and" not in row[5]:
                    return 1
        else:
            return 0
    conn.close()

    def exportClient(self):
        lis1=[]
        conn = sqlite3.connect("test.db")
        cursor = conn.execute("SELECT * from CLIENT")
        for row in cursor:
            lis1.append(row)

        return lis1
        conn.close()


    def __str__(self):
        conn = sqlite3.connect("test.db")
        cursor = conn.execute("SELECT fname, lname, sex, id, birth,vaccine, date, phone from CLIENT")
        for row in cursor:
            print("first name = ", row[0])
            print("last name = ", row[1])
            print("sex = ", row[2])
            print("id = ", row[3])
            print("birth = ", row[4])
            print("vaccine = ", row[5])
            print("date = ", row[6])
            print("phone = ", row[7], "\n")
        print("Operation done successfully")
        conn.close()
