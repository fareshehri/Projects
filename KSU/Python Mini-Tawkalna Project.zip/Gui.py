import tkinter as tk
from datetime import datetime
from tkinter import ttk
import tkinter.messagebox
from tkinter import filedialog as fd
import csv
import random
import Data


class GUI:
     def __init__(self):
          self.app = tk.Tk()
          self.app.title("Mini-Tawkalna")
          self.app.configure(bg='#005555')
          self.app.title('Mini-Tawakalna')
          self.app.geometry('700x400')
          self.app.iconphoto(False, tk.PhotoImage(file='T.png'))

          self.notebook = ttk.Notebook(self.app)
          self.notebook.grid(column=0, row=0)
     #main frame
          self.labelframe = tk.LabelFrame(self.app, text="")#First Tab first frame
          self.frame = tk.Frame(self.labelframe)
          self.labelframe2 = tk.LabelFrame(self.app, text="")#second Tab first frame
          self.frame2 = tk.Frame(self.labelframe2)
          self.labelframe3 = tk.LabelFrame(self.app, text="")  # Third Tab first frame
          self.frame3 = tk.Frame(self.labelframe3)

     #secondrey frames
          self.labelframe11 = tk.LabelFrame(self.frame, text="Basic Information")
          self.frame11 = tk.LabelFrame(self.labelframe11)
          self.labelframe12 = tk.LabelFrame(self.frame, text="Vaccine")
          self.frame12 = tk.LabelFrame(self.labelframe12)
          self.labelframe13 = tk.LabelFrame(self.frame, text="")
          self.frame13 = tk.LabelFrame(self.labelframe13)



          self.labelframe21 = tk.LabelFrame(self.frame2, text="User Info")
          self.frame21 = tk.LabelFrame(self.labelframe21)
          self.labelframe22 = tk.LabelFrame(self.frame2, text="Result")
          self.frame22 = tk.LabelFrame(self.labelframe22)

          self.labelframe31 = tk.LabelFrame(self.frame3, text="Import")  # Third Tab first frame
          self.frame31 = tk.Frame(self.labelframe31)
          self.labelframe32 = tk.LabelFrame(self.frame3, text="Export")  # Third Tab first frame
          self.frame32 = tk.Frame(self.labelframe32)


#Check-In Input
          self.cifname=tk.Label(self.labelframe11, text='Enter first name:')
     # Var fname
          fname = tk.StringVar()
          self.fname = tk.Entry(self.labelframe11, width=10,textvariable=fname)

          self.cilname = tk.Label(self.labelframe11, text='Enter last name:')
     # Var lname
          lname =tk.StringVar()
          self.lname = tk.Entry(self.labelframe11, width=10,textvariable=lname)


          self.ciid = tk.Label(self.labelframe11, text='Enter ID:')
     # Var Id
          id =tk.IntVar(None,"")
          self.id = tk.Entry(self.labelframe11, width=10,textvariable=id)
     # Var Sex
          self.sex = self.sexVar = tk.StringVar(None, "Male")
          sex1 = tk.Radiobutton(self.labelframe11, text="Male", variable=self.sexVar, value="Male")
          sex2 = tk.Radiobutton(self.labelframe11, text="Female", variable=self.sexVar, value="Female")

          inyear= ("1900","1901")
          for i in range(1902,2010):
               inyear = inyear + (i,)
          self.ciyear = tk.Label(self.labelframe11, text='Enter Birth Year:')
     #Var Year
          self.birth = tk.IntVar(None)

          self.year = ttk.Combobox(self.labelframe11, textvariable=self.birth)
          self.year['values'] = inyear
          self.year.current(80)

          self.civac = tk.Label(self.labelframe12, text='Enter Vaccine Type:')
     # Var Vaccine
          vaccine = tk.StringVar(None)
          invaccine = ("Pfizer", "AstraZeneca", "Moderna", "J&J")
          self.vaccine = ttk.Combobox(self.labelframe12, textvariable=vaccine)
          self.vaccine['values'] = invaccine
          self.vaccine.current(0)

     # Var date
          date= datetime.today().strftime('%d/%m/%Y %I:%M %p')
          self.datel=tk.Label(self.labelframe11, text='Enter Date:')
          vardy=tk.StringVar(None,date)
          self.datey=tk.Entry(self.labelframe11, width=20, textvariable=vardy)

     # Var phone
          self.ciphone = tk.Label(self.labelframe11, text='Enter Phone Number:(05xxxxxxx)')
          phone = tk.IntVar(None,"05")
          self.phone = tk.Entry(self.labelframe11, width=10, textvariable=phone)

          self.submit = tk.Button(self.labelframe13, text='Submit',command=self.check_all)
#immunity Check
          self.iclid = tk.Label(self.labelframe21, text='Enter the ID:')
          # Var ic Id
          icid = tk.IntVar(None, "")
          self.icid = tk.Entry(self.labelframe21, width=10, textvariable=id)
          self.submitim = tk.Button(self.labelframe21, text='Submit', command=self.checkim)

          #second frame
          self.iclcolor = tk.Label(self.labelframe22, text='Status:') #change
          self.ictwo=['green1.png','green2.png','green3.png','green4.png']
          self.icone =['yellow1.png','yellow2.png','yellow3.png','yellow4.png']
          self.icnon =['red1.png','red2.png','red3.png','red4.png']
          self.iccolor = tkinter.PhotoImage()
          self.canvas = tkinter.Canvas(self.labelframe22, width=200, heigh=200,)
          self.canvas.create_image(0, 0, anchor=tkinter.NW, image=self.iccolor)


#import/export
          self.imlim = tk.Label(self.labelframe31, text='Import File:')
          imbutton = tk.Button(self.labelframe31, text='Click to Import File', command=self.importfile)

          #second frame
          self.exlex = tk.Label(self.labelframe32, text='Export File:')
          exbutton = tk.Button(self.labelframe32, text='Click to Export File', command=self.exportfile)

          #frames
          self.frame.grid(),self.frame2.grid(),self.frame3.grid()
          self.frame11.grid(),self.frame12.grid(),self.frame13.grid()
          self.frame21.grid(),self.frame22.grid(),
          self.frame31.grid(),self.frame32.grid()

     #labels
          self.labelframe.grid(),self.labelframe2.grid(),self.labelframe3.grid()
          self.labelframe11.grid(column=0, row=0),self.labelframe12.grid(column=0, row=1),self.labelframe13.grid(column=0, row=2)
          self.labelframe21.grid(column=0, row=0),self.labelframe22.grid(column=0, row=1)
          self.labelframe31.grid(column=0, row=0),self.labelframe32.grid(column=0, row=1)

     #inputs
     #check-in tab
          #labels
          self.cifname.grid(column=0, row=0),self.cilname.grid(column=0, row=1),self.ciid.grid(column=0, row=2),self.ciyear.grid(column=0, row=3),self.ciphone.grid(column=0, row=4),self.datel.grid(column=0, row=5)
          #Entrys
          self.fname.grid(column=1, row=0),self.lname.grid(column=1, row=1),self.id.grid(column=1, row=2),self.year.grid(column=1, row=3),self.vaccine.grid(column=1, row=0),self.phone.grid(column=1, row=4),
          self.datey.grid(column=1, row=5)
          #RadioButton
          sex1.grid(column=2, row=0),sex2.grid(column=2, row=1)
          #SubmitionButton
          self.submit.grid(column=0, row=0)


     #immunity check tab
          self.iclid.grid(column=2, row=0)
          self.icid.grid(column=3, row=0,pady=10,padx=10)
          self.submitim.grid(column=4, row=0,pady=10,padx=10)
          #second frame
          self.iclcolor.grid(column=0, row=0)
          self.canvas.grid(column=0, row=0)

     #import/export
          self.imlim.grid(column=0, row=0)
          imbutton.grid(column=0, row=2)
          #second frame
          self.exlex.grid(column=0, row=0)
          exbutton.grid(column=0, row=2)


     #Notebooks
          self.notebook.add(self.labelframe, text='Check-In')
          self.notebook.add(self.labelframe2, text='Immunity Check')
          self.notebook.add(self.labelframe3, text='Import/Export')
          self.app.mainloop()

     # Validation

     def check_all(self):
          try:
               z = True
               datetime.strptime(self.datey.get(), "%d/%m/%Y %I:%M %p")
          except ValueError:
               z = False
          if   str(self.fname.get()).isalpha():
               if str(self.lname.get()).isalpha():
                    if str(self.id.get()).isdigit() and len(str(self.id.get())) == 10:
                         if str(self.year.get()).isdigit() and len(str(self.year.get())) == 4:
                              if str(self.phone.get()).isdigit() and len(str(self.phone.get())) == 10 and str(self.phone.get()).startswith("05"):
                                   if z==True:
                                        p=Data.Data(self.fname.get(),self.lname.get(),self.sex.get(),self.id.get(),self.year.get(),self.vaccine.get(),str(self.datey.get()),self.phone.get())
                                        if Data.Data.addClient(p): tkinter.messagebox.showinfo('Response', 'All Good.')
                                        else: tkinter.messagebox.showinfo('Response', 'Have Two Shots.')
                                   else:
                                        tkinter.messagebox.showinfo('Response','Date Format is  (DD/MM/YYYY HH M)')
                              else:
                                   tkinter.messagebox.showinfo('Response', 'phone must be numbers only and start with 05 and 10 digit ..')
                         else:
                              tkinter.messagebox.showinfo('Response', 'birth must be 4 digits ..')

                    else:
                         tkinter.messagebox.showinfo('Response', 'id must be numbers only and 10 digit only.')
               else:tkinter.messagebox.showinfo('Response', 'Last name must be Letters only.')
          else:
               tkinter.messagebox.showinfo('Response', 'First name must be Letters only .')

     def checkim(self):
          if str(self.icid.get()).isdigit() and len(str(self.icid.get())) == 10:
               if Data.Data.checker(self.icid.get()) == 0:
                    self.iccolor = tkinter.PhotoImage(file=random.choice(self.icnon))
                    self.canvas.create_image(0, 0, anchor=tkinter.NW, image=self.iccolor)
               if Data.Data.checker(self.icid.get()) == 1:
                    self.iccolor = tkinter.PhotoImage(file=random.choice(self.icone))
                    self.canvas.create_image(0, 0, anchor=tkinter.NW, image=self.iccolor)
               if Data.Data.checker(self.icid.get()) == 2:
                    self.iccolor = tkinter.PhotoImage(file=random.choice(self.ictwo))
                    self.canvas.create_image(0, 0, anchor=tkinter.NW, image=self.iccolor)
          else:
               tkinter.messagebox.showinfo('Response', 'id must be numbers only and 10 digit only.')

     def importfile(self):
          try:
               name = fd.askopenfilename()
               f = open(name)
               csvreader = csv.reader(f)
               for row in csvreader:
                    imfn=row[0]
                    imln = row[1]
                    imse = row[2]
                    imid = row[3]
                    imbi = row[4]
                    imva = row[5]
                    imda = row[6]
                    imph = row[7]
                    if("and" in imva):
                         pfi=imva.upper().count("PFIZER")
                         ast = imva.upper().count("ASTRAZENECA")
                         mod = imva.upper().count("MODERNA")
                         jj = imva.upper().count("J&J")
                         x=pfi+ast+mod+jj
                         if(x>1):
                              Data.Data.importClient(imfn,imln,imse,imid,imbi,imva,imda,imph)
                    else:
                         imva.upper().count("J&J")
                         if imva.upper().count("PFIZER") or imva.upper().count("ASTRAZENECA") or imva.upper().count("MODERNA") or imva.upper().count("J&J"):
                              Data.Data.importClient(imfn, imln, imse, imid, imbi, imva, imda, imph)

               tkinter.messagebox.showinfo('Response','Done.')
               f.close()
          except:
               tkinter.messagebox.showinfo('Response', 'Failed.')


     def exportfile(self):
          dirct = fd.askdirectory(master=self.app, title="Select your Source directory")
          tmdirct=str(dirct)+"/Database.csv"
          try:
               file= open(tmdirct, 'w',newline='')
               csvwriter = csv.writer(file)
               csvwriter.writerows(Data.Data.exportClient(self))
               tkinter.messagebox.showinfo('Response', 'Done.')
          except:
               tkinter.messagebox.showinfo('Response', 'Failed.')

GUI()
input()